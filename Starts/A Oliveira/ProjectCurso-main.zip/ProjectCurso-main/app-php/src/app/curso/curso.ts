//Classe
export class Curso{

    //construtor
    constructor(
        nomeCurso:string, valorCurso:number, idCurso?:number
    ){}
}