export declare type CustomKeyboardEvent = KeyboardEvent;
